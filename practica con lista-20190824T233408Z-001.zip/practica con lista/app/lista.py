if __name__ =="__main__":
    #Crear lista
    lista1 = ("ba", "beh", "bih", "boh", "buh")
    print(lista1)
    
    #Acceder a lista
    print(lista1)
    for elemento in lista1:
        print(elemento)
        
    #compara lista
    lista2 = ("beh","bah","boh","bih")
    if lista1 == lista2:
        print("son identicas")
        
    #longitud lista
    print(len(lista1))
    
    #concatenar lista
    print(lista1+lista2)
    
    #numero minimo y maximo
    lista3=[1, 2, 3, 4, 5]
    print(max(lista3))
    print(min(lista3))
    
    #lista enlazada
    lista4=["Esto es", [1,2,3], 75]
    print(lista4)