import unittest
from app import sumar

class SumaTest(unittest.TestCase): #Debo colocar esl "test" para saber que es un test
    def test_sumar(self):
        self.assertEqual(sumar(2,2), 4) #hace aseveracion de igualdad

if __name__ == '__main__':
    unittest.main()