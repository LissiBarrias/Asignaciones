def sumar(x,y):
    return x+y

if __name__ == '__main__':
    sumar(2,2)