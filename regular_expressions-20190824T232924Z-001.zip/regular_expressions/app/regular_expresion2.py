import re

palabra = input ("Palabra a evaluar:")

if re.match('.asa', palabra):
#evaluara exclusivamente si la palabra tiene esa terminacion
##if re.match('.a.a', palabra);
##if re.match('\.a.a', palabra); para evaluar una palabra que empieze EXCLUSIVAMENTE CON un punto (.)
##if re.match('jpg|png|gif|, palabra);
##if re.match(\.('jpg|png|gif|), palabra); para que por fuerza acepte estos archivos

print("Coincidencia")
else:
    print("Sin coincidencia")