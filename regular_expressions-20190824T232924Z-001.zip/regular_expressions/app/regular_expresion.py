import re

palabra = input ("Palabra a evaluar:")

if re.match('casa', palabra): #evaluara exclusivamente si la palabra es como esa
    print("Coincidencia")
else:
    print("Sin coincidencia")