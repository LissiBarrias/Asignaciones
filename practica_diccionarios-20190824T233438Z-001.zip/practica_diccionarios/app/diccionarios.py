if __name__ =="__main__":
    equipos_lpf = {
        'Arabe Unido': 15,
        'CAI': 2,
        'Tauro': 13,
        'San Francisco': 10,
        'Plaza Amador': 7,
        'Universitario': 2,
        'Sporting SM': 1,
        #mis llaves son todos los equipos. el identificador de cada elemento
        #el valor asociado serian los numeros de cada identificador
    }
    print(equipos_lpf)
    #para acceder a un valor del diccionario, lo hago con el nombre del diccionario y entre {} coloco el nombre 

    #equipos_lpf['Alianza FC'] = 0
    #print(equipos_lpf)

    #del equipos_lpf['Alianza FC'] #del borra un registro
    #print(equipos_lpf)
    
    #print(equipos_lpf.get('Arabe Unido')) #genera el valor de Arabe Unido
    #print(equipos_lpf.get('Atletico Veraguense')) #buscará este valor, pero como no existe, lo pondrá como None
    #para que me de los resultados, debo borrar "clear"
    
    e=equipos_lpf.items()#item trae una lista compuesta de cada uno de los elementos del diccionario
    print(e)
    
    e1= equipos_lpf.keys()
    print(e1)
    
    e2= equipos_lpf.values()
    print(e2)

    #equipos_lpf.clear()#clear borraba los datos
    #print(equipos_lpf)