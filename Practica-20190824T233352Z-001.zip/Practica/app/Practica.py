if __name__ == '__main__':
    print('ONEPLUS: ITS ABOUT SPEED)
    print("------------------\n")

        client = input("Client: ")

    print('\nMENU')
    print('1. Mondongo\t$1.50')
    print('2. Lengua\t$0.75')
    print('3. Pata\t\t$2.00')
    opcion = int(input("Opcion: "))