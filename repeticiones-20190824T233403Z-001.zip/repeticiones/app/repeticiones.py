import re

palabra = input ("Palabra a evaluar:")

if re.match('[A-Z][a-z]+\s[A-Z](\.|[a-z]*)', palabra):
    print("Coincidencia")
else:
    print("Sin coincidencia")