import re
#Inicio y final
palabra = input ("Palabra a evaluar:")

if re.match('[A-Z][a-z]\.(com)$', palabra):
    print("Coincidencia")
else:
    print("Sin coincidencia")