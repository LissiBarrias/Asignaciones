if __name__ == "__main__":
 print ("FONDA LA SABROSONA")
 print ("-------------------------\n") #tabulado. salto de linea. campanita

print("y")
cliente = input("Cliente: ") #leyendo un dato por teclado. input, funcion. mensaje que recibira el usuario. aca es directo. no declaro varibales.
print("x")
print ("\n MENU")
print ("1. Mondongo \t $1.50")
print ("2. Lengua \t $0.75")
print ("3. Pata \t $2.00")
opcion = int(input("Opcion: "))#int vuelve entero el valor que genere input
    
if opcion == 1:
    precio = 1.5
elif opcion == 2:
    precio = 0.75
elif opcion == 3:
    precio = 2.0
else:
    print ("Opcion invalida")

total = precio * 1.07
                            
print(cliente + ", debe pagar $" + str (total)) #str, funcion para convertir lo que pase alli en una cadena