if __name__ == '__main__':
    print('FONDA LA SABROSONA PRO')
    print("------------------\n")

    print('\nMENU 1')
    menu1 = ("arepita", "arroz", "asas", "asas", "asasas")
    print(menu1)

    print('\nMENU 2')
    menu2 = ("sopa", "arroz", "ensalada", "pizza", "mamallena")
    print(menu2)

    print('\nMENU 3')
    menu3 = ("Caña", "lenteja", "queso", "bofe", "sauce")
    print(menu3)

menu = int(input("Escoga el menu: "))
    if menu == 1:
        print('El menu elegido fue: ', {menu1})
            break
        elif opcion == 2:
            precio = 0.75
        print('El menu elegido fue: ', {menu3})
            break
        elif opcion == 3:
        print('El menu elegido fue: ', {menu3})
= "pata"
            break
